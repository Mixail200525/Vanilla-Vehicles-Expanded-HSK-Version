# VanillaVehiclesExpanded
Repository for Vanilla Vehicles Expanded core module
